﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CivicSystem.Views.Suggestion;

public class Index : PageModel
{
    public void OnGet()
    {
        
    }
}