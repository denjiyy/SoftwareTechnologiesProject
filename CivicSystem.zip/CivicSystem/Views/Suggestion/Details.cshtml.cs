﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CivicSystem.Views.Suggestion;

public class Details : PageModel
{
    public void OnGet()
    {
        
    }
}