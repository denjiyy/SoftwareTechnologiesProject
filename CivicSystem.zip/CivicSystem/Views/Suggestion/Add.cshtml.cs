﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CivicSystem.Views.Suggestion;

public class Add : PageModel
{
    public void OnGet()
    {
        
    }
}