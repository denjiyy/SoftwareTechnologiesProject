﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CivicSystem.Views.Suggestion;

public class Edit : PageModel
{
    public void OnGet()
    {
        
    }
}