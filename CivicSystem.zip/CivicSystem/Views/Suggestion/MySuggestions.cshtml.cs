﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CivicSystem.Views.Suggestion;

public class MySuggestions : PageModel
{
    public void OnGet()
    {
        
    }
}