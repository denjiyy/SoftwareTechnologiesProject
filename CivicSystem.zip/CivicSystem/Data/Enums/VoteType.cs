﻿namespace CivicSystem.Data.Enums
{
    public enum VoteType
    {
        Downvote = -1,
        Upvote = 1,
    }
}
